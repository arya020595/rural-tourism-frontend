import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { register } from 'swiper/element/bundle';
import { Router } from '@angular/router';
import Swiper from 'swiper';
import { ApiService } from '../services/api.service';
import { NgForm } from '@angular/forms';
import { NavController } from '@ionic/angular';

register();

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.page.html',
  styleUrls: ['./add-item.page.scss'],
})
export class AddItemPage implements OnInit {

  @ViewChild('swiper')
  swiperRef: ElementRef | undefined;
  swiper?: Swiper

  currentStep = 1; // Track the current step (1 = Step 1, 2 = Step 2, 3 = Step 3)
  selectedOption: string = '';

  
  
activityData = {
  activity_id: '',
  activity_name: '',
  description: '',
  price: '',
  image: '',        // Can be a filename or base64 path
  district: '',
  things_to_know: [] as { title: string; description: string }[],
  user_id: localStorage.getItem('uid'),
  address: '',
  showInSuggestions: false, 
};

imagePreview: string | null = null;



newThingToKnow = {
  title: '',
  description: ''
};


  accomData = {
    homest_id: '',
    homest_name: '',
    location: '',
    description: '',
    price: '',
    user_id: localStorage.getItem('uid'),
  };

  constructor(
    private router: Router,
    private apiService: ApiService,
    private navController: NavController
  ) { }

  ngAfterViewInit() {
    this.swiperReady();
  }

  ngOnInit() {
    
  }

  //dialog box
  isAlertOpen = false;
  alertButtons = [
    {
      text: 'OK',
      handler: () => {
        // Navigate to the /home route when the button is pressed
        this.navController.navigateForward('/home', {
          animated: true,        // Enable animation
          animationDirection: 'back'  // Can be 'forward' or 'back' for custom direction
        });
      },
    },
  ];

  cancelButton = [
    {
      text: 'Tidak',
      role: 'cancel',
      handler: () => {
        console.log('Alert canceled');
      },
    },
    {
      text: 'Ya',
      role: 'confirm',
      handler: () => {
        this.navController.navigateForward('/home', {
          animated: true,        // Enable animation
          animationDirection: 'back'  // Can be 'forward' or 'back' for custom direction
        });
      },
    },
  ];

  setOpen(isOpen: boolean) {
    this.isAlertOpen = isOpen;
  }


  addThingToKnow() {
  const { title, description } = this.newThingToKnow;
  if (title.trim() && description.trim()) {
    this.activityData.things_to_know.push({ title, description });
    this.newThingToKnow = { title: '', description: '' }; // reset form
  }
}

removeThingToKnow(index: number) {
  this.activityData.things_to_know.splice(index, 1);
}


onImageSelected(event: any) {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = () => {
      this.imagePreview = reader.result as string;
      this.activityData.image = this.imagePreview;  // Save base64 string
    };
    reader.readAsDataURL(file);
  }
}


  generateAccommId(): string {
    const randomPart = Math.floor(Math.random() * 10000000); // Random number between 0 and 9999999 (7 digits)
    const formattedRandomPart = randomPart.toString().padStart(8, '0'); // Ensure it has 7 digits
    return `acc_${formattedRandomPart}`; // Concatenate 'RE' with the 7-digit random number
  }

  generateActId(): string {
    const randomPart = Math.floor(Math.random() * 10000000); // Random number between 0 and 9999999 (7 digits)
    const formattedRandomPart = randomPart.toString().padStart(8, '0'); // Ensure it has 7 digits
    return `act_${formattedRandomPart}`; // Concatenate 'RE' with the 7-digit random number
  }


   //initialize swiper
   swiperReady() {

    // Ensure swiperRef is initialized, and access the swiper instance
  if (this.swiperRef?.nativeElement) {
    this.swiper = this.swiperRef.nativeElement.swiper;

    // Check if swiper is initialized before modifying it
    if (this.swiper) {
      this.swiper.allowTouchMove = false; // Disable swiping
    }
  }
  }

  // swiper navigation
  goNext() {
    // this.swiper?.slideNext()
    this.swiper?.slideNext();
    console.log('here');
    
  }

  goPrev() {
    this.swiper?.slidePrev();
  }

   // Go to the next step
   goToStep(step: number) {
    this.currentStep = step;
  }

  // Set the selected option (Activity or Accommodation)
  selectOption(option: string) {
    this.selectedOption = option;
    this.goNext();
  }


  onShowInSuggestionsChange() {
  console.log('Show in Suggestions changed:', this.activityData.showInSuggestions);
}

  submitForm(){
    if (this.selectedOption === "accommodation") {
      this.accomData.homest_id = this.generateAccommId();
      
      this.apiService.createAccom(this.accomData).subscribe(
        (Response)=>{
          console.log(Response);
          console.log('Accommodation Data:', this.accomData);
          this.setOpen(true);
        },
        (error)=>{
          console.log(error);
          alert("Error: " +error)
        }
      )
      
    }

    if (this.selectedOption === "activity") {
      this.activityData.activity_id = this.generateActId();

        // Convert array to JSON string if needed by backend
        const dataToSend = {
          ...this.activityData,
          showInSuggestions: this.activityData.showInSuggestions ? 1 : 0,
          things_to_know: JSON.stringify(this.activityData.things_to_know)
        };





      this.apiService.createActivity(dataToSend).subscribe(
        (Response)=>{
          console.log(Response);
          console.log('Activity Data:', this.activityData);
          this.setOpen(true);
        },
        (error)=>{
          console.log(error);
          alert("Error: " +error)
        }
      )
      
    }
    
   
  }

   // checking
   onSlideChange(event: any) {
    // console.log(event)
  }

  // Add a method to check if the form is complete
  isFormComplete() {
    // Check if the required fields for the selected option are filled out
    if (this.selectedOption === 'accommodation') {
      return this.accomData.homest_name && this.accomData.location;
    } else if (this.selectedOption === 'activity') {
      return this.activityData.activity_name && this.activityData.activity_name;
    }
    return false;
  }


}
