import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { authGuard } from './auth.guard';

const routes: Routes = [
  // {
  //   path: 'home',
  //   loadChildren: () => import('./home/home.module').then( m => m.HomePageModule),
  //   canActivate: [authGuard]  // Apply the authGuard to protect this route
  // },

  //This is the starting point when you run the code
  {
    path: 'tourist/home',
    loadChildren: () => import('./tourist/home/home.module').then( m => m.HomePageModule),
    // canActivate: [authGuard]  // Apply the authGuard to protect this route
  },
  {
    path: '',
    redirectTo: 'tourist/home',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'acco-form',
    loadChildren: () => import('./acco-form/acco-form.module').then( m => m.AccoFormPageModule),
    canActivate: [authGuard]
  },
  {
    path: 'receipt/:receipt_id',
    loadChildren: () => import('./receipt/receipt.module').then( m => m.ReceiptPageModule),
    canActivate: [authGuard]
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'add-item',
    loadChildren: () => import('./add-item/add-item.module').then( m => m.AddItemPageModule),
    canActivate: [authGuard]
  },
  {
    path: 'activity-form',
    loadChildren: () => import('./activity-form/activity-form.module').then( m => m.ActivityFormPageModule),
    canActivate: [authGuard]
  },
  {
    path: 'receipt-activity/:receipt_id',
    loadChildren: () => import('./receipt-activity/receipt-activity.module').then( m => m.ReceiptActivityPageModule),
    canActivate: [authGuard]
  },
  {
    path: 'reset-passs',
    loadChildren: () => import('./reset-passs/reset-passs.module').then( m => m.ResetPasssPageModule)
  },
  {
    path: 'package-form',
    loadChildren: () => import('./package-form/package-form.module').then( m => m.PackageFormPageModule)
  },
  {
    path: 'receipt-package/:receipt_id',
    loadChildren: () => import('./receipt-package/receipt-package.module').then( m => m.ReceiptPackagePageModule)
  },
  {
    path: 'transaction',
    loadChildren: () => import('./transaction/transaction.module').then( m => m.TransactionPageModule)
  },
  {
    path: 'view-receipt/:receipt_id',
    loadChildren: () => import('./view-receipt/view-receipt.module').then( m => m.ViewReceiptPageModule)
  },
  {
    path: 'faq',
    loadChildren: () => import('./faq/faq.module').then( m => m.FAQPageModule)
  },
  {
    path: 'booking-home',
    loadChildren: () => import('./booking-home/booking-home.module').then( m => m.BookingHomePageModule)
  },
  {
    path: 'about',
    loadChildren: () => import('./about/about.module').then( m => m.AboutPageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'faq',
    loadChildren: () => import('./tourist/faq/faq.module').then( m => m.FaqPageModule)
  },
  {
  path: 'tourist/activity-detail/:id',
  loadChildren: () =>
    import('./tourist/activity-detail/activity-detail.module').then(m => m.ActivityDetailPageModule)
},
  {
    path: 'tourist/accomodation-detail',
    loadChildren: () => import('./tourist/accomodation-detail/accomodation-detail.module').then( m => m.AccomodationDetailPageModule)
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      preloadingStrategy: PreloadAllModules,
      initialNavigation: 'enabledBlocking'
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
