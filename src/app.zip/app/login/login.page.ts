import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service'; 
import { NavController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  username: string = '';
  password: string = '';

  constructor(
    private apiService: ApiService, 
    private navCtrl: NavController,
    private toastController: ToastController) {}


    async errorToast(msg: any) {
      const toast = await this.toastController.create({
        message: "Invalid Username or Password  ",
        duration: 1500,
        position: "middle",
        cssClass: 'error-toast',
        icon: 'alert-circle'
      });
  
      await toast.present();
    }

    submitted = false;

    login(form: NgForm){
      this.submitted = true;

      if(form.valid){

        // console.log(this.password)
      const credentials = { username: this.username, password: this.password };

      this.apiService.login(credentials).subscribe(
        response => {
          console.log('Login successful:', response);
          // localStorage.setItem('token', response.token);
          localStorage.setItem('uid', response.id);
          this.navCtrl.navigateRoot('/home');
        },
        error => {
          console.error('Login failed:', error);
          this.errorToast(error.status)
          // alert('Invalid username or password');
          // console.log(error);
        }
      );

      }
      
      
    }

  ngOnInit() {
    this.checkStandaloneMode();
  }

checkStandaloneMode() {
  if (window.matchMedia('(display-mode: standalone)').matches) {
    // Add 'standalone-app' class to body for full-screen behavior
    document.body.classList.add('standalone-app');
  } else {
    document.body.classList.remove('standalone-app');
  }
}

  forgotPassword(){
    this.navCtrl.navigateForward(['/reset-passs'])
  }

  register(){
    this.navCtrl.navigateForward(['/register']);
  }

    backHome(){
    this.navCtrl.navigateForward('/tourist/home', {
      animated: true,        // Enable animation
      animationDirection: 'back'  // Can be 'forward' or 'back' for custom direction
    });
  }



}
