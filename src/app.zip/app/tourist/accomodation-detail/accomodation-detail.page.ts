import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accomodation-detail',
  templateUrl: './accomodation-detail.page.html',
  styleUrls: ['./accomodation-detail.page.scss'],
})
export class AccomodationDetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
