// import { Component, OnInit } from '@angular/core';
// import { MenuController } from '@ionic/angular';
// import { ApiService } from '../services/api.service';

// @Component({
//   selector: 'app-home',
//   templateUrl: './home.page.html',
//   styleUrls: ['./home.page.scss'],
// })
// export class HomePage implements OnInit {

//   selectedSegment: string = 'activity'; 

//   activities: any[] = [];

//   //constructor(private menu: MenuController) {} 
//     constructor(private apiService: ApiService) {} 


//   selectSegment(segment: string) {
//     this.selectedSegment = segment;
//     this.menu.close(); //
//   }

//   ngOnInit() {
//   }
// }

import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

  selectedSegment: string = 'activity'; 
  activities: any[] = [];

  constructor(
    private apiService: ApiService,
    private menu: MenuController,
    private router: Router
  ) {}

  goToDetail(id: string) {
  this.router.navigate(['/tourist/activity-detail', id]);
}

  selectSegment(segment: string) {
    this.selectedSegment = segment;
    this.menu.close(); // Close menu after selecting
  }

  ngOnInit() {
    this.loadActivities();
  }


  getImageSource(image: string): string {
  return image?.startsWith('data:image') ? image : `data:image/jpeg;base64,${image}`;
}
  
// getImageSource(image: string): string {
//   if (!image.startsWith('data:image')) {
//     return 'data:image/jpeg;base64,' + image;
//   }
//   return image;
// }

ionViewWillEnter() {
  this.menu.enable(true, 'mainMenu'); // Ensure menu is enabled when page is entered
}

//Anything from the Operator is set to recommendation should set it here
get suggestedActivities() {
  return this.activities.filter(activity => {
    return [true, 1, '1'].includes(activity.show_in_suggestions)
        || [true, 1, '1'].includes(activity.showInSuggestions);
  });
}




loadActivities() {
  this.apiService.getAllActivity().subscribe(
    (data: any[]) => {
      this.activities = data;
      console.log('Loaded activities:', data);
       data.forEach(act => console.log(act.activity_name, act.showInSuggestions));
    },
    (error: any) => {   // <-- add ': any' here
      console.error('Failed to load activities:', error);
    }
  );
}


}

