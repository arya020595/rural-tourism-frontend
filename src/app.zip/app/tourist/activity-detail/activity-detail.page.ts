import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NavController } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-activity-detail',
  templateUrl: './activity-detail.page.html',
  styleUrls: ['./activity-detail.page.scss'],
})
export class ActivityDetailPage implements OnInit {
  activityId: string = '';
  activityData: any;

  constructor(
    private route: ActivatedRoute,
    private navCtrl: NavController,
    private api: ApiService
  ) {}

  ngOnInit() {
    this.activityId = this.route.snapshot.paramMap.get('id') || '';
    console.log('Loaded activityId:', this.activityId);  // Debug this
    this.loadActivity();
  }

  backHome(){
    this.navCtrl.navigateForward('/tourist/home', {
      animated: true,        // Enable animation
      animationDirection: 'back'  // Can be 'forward' or 'back' for custom direction
    });
  }

  loadActivity() {
  this.api.getActivityById(this.activityId).subscribe(
    (data) => {
      // If things_to_know is a string, parse it
      if (typeof data.things_to_know === 'string') {
        try {
          data.things_to_know = JSON.parse(data.things_to_know);
        } catch (e) {
          console.warn('Failed to parse things_to_know', e);
          data.things_to_know = []; // fallback
        }
      }

      this.activityData = data;
    },
    (error) => {
      console.error('Error fetching activity:', error);
    }
  );
}



  // loadActivity() {
  //   this.api.getActivityById(this.activityId).subscribe(
  //     (data) => {
  //       this.activityData = data;
  //     },
  //     (error) => {
  //       console.error('Error fetching activity:', error);
  //     }
  //   );
  // }
}
