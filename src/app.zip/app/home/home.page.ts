import { Component } from '@angular/core';
import { AccoFormPage } from '../acco-form/acco-form.page';
import { ApiService } from '../services/api.service';
import { MenuController, ToastController } from '@ionic/angular';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})

export class HomePage {
  uid: any; // Store the user ID
  user: any; // Object to hold user data
  constructor(
    private apiService: ApiService,
    private menuCtrl: MenuController,
    private router: Router,
    private toastController: ToastController,
    private http: HttpClient // Inject HttpClient for testing
  ) {}
  async logoutToast() {
    const toast = await this.toastController.create({
      message: "User Logged Out",
      duration: 1500,
      position: "bottom",
      cssClass: 'error-toast',
      icon: 'alert-circle'
    });
    await toast.present();
  }

  ngOnInit(): void {
    this.uid = localStorage.getItem('uid'); // Retrieve user ID from local storage
    this.loadUser();
    // :mag: Debug: Test connection to backend
    this.http.get(`${environment.apiUrl}/test`).subscribe({
      next: res => console.log(':white_check_mark: Backend connected:', res),
      error: err => console.error(':x: Backend connection failed:', err)
    });

    this.apiService.testBackend().subscribe({
      next: res => console.log('Backend Success:', res),
      error: err => console.error('Backend Error:', err)
    });

  }

logOut() {
  localStorage.clear();

  // Disable menu so it won't stay open or active
  this.menuCtrl.enable(false, 'mainMenu');
  this.menuCtrl.close();

  this.logoutToast();
  this.router.navigate(['/tourist/home']);
}

  closeMenu() {
    this.menuCtrl.close();
  }

  openFirstMenu() {
    this.menuCtrl.open('menu');
  }

  goToAdd() {
    console.log('it works!');
  }

  loadUser() {
    if (this.uid) {
      this.apiService.getUserByID(this.uid).subscribe(
        (data) => {
          this.user = data;
        },
        (error) => {
          console.log(error);
        }
      );
    } else {
      console.log("uid not found in storage");
    }
  }
}