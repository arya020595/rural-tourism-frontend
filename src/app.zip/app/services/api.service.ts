import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

// Define the interface for the response from the backend
export interface PdfResponse {
  success: boolean;
  fileUrl: string;
}

@Injectable({
  providedIn: 'root'
})


export class ApiService {
  // private apiUrl = 'http://localhost:3000/api'; // local testing
  // private apiUrl = 'http://192.168.100.75:3000/api'; // dont use
  private apiUrl = environment.apiUrl; // for server production
  constructor(
    private http: HttpClient,


  ) {}
  // Call to void the receipt
  voidReceipt(receiptID: string): Observable<any> {
  return this.http.post(`${this.apiUrl}/receipts/void-receipt`, { receiptID });
  }

  testBackend(): Observable<any> {
    return this.http.get(`${this.apiUrl}/test`);
  }

  //USER API

  //login
  login(credentials: {username: string; password: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/users/login`, credentials);
  }

  //get specific user by id
  getUserByID(user_id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/users/${user_id}`);
  }

  getAllUser(): Observable<any>{
    return this.http.get(`${this.apiUrl}/users`); 
  }

  getActivityById(id: string) {
  return this.http.get<any>(`${this.apiUrl}/activity/${id}`);
}


  //create user (register)
  createUser(form: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/users`, form);
  }

  //reset password
  resetPassword(username: string, question: string, securityAnswer: string, newPassword: string): Observable<any> {
    const payload = { username, question, securityAnswer ,newPassword };
    return this.http.post(`${this.apiUrl}/users/reset-pass`, payload);
  }


  //FORM API

  //create form
  createForm(form: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/form`, form);
  }

  // get form/receipt by id
  getFormByID(form_id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/form/${form_id}`);
  }

   // Modify the function to accept FormData
   generatePdfFromImage(formData: FormData): Observable<any> {
    const url = `${this.apiUrl}/receipts/generate-pdf-from-image`;
    
    // Make a POST request to send the FormData (which contains the file)
    return this.http.post<any>(url, formData);
  }

  // Upload the image as FormData
  uploadPdf(formData: FormData): Observable<any> {
    return this.http.post(`${this.apiUrl}/receipts/generate-pdf-from-image`, formData);
  }

  // load transaction history
  getFormsByUser(user_id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/form/trans/${user_id}`);
  }

  // voidTransaction(user_id: string): Observable<any> {
  //   return this.http.get(`${this.apiUrl}/form/trans/${user_id}`);
  // }

  //ACCOMMODATION API

  //add new accommodation
  createAccom(form: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/accom`, form);
  }

  // get all accomodations
  getAllAccommodations(): Observable<any> {
    return this.http.get(`${this.apiUrl}/accom`); 
  }

  // get all accommodations by User
  getAllAccomByUser(user_id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/accom/user/${user_id}`);
  }


  //ACTIVITY API

  //add new activity
  createActivity(form: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/activity`, form);
  }
  
  // get all activity
  getAllActivity(): Observable<any> {
    return this.http.get(`${this.apiUrl}/activity`); 
  }

  getAllActByUser(user_id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/activity/user/${user_id}`);
  }

  // Other methods...
}

